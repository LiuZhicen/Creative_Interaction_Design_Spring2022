var jsonData = jsonData;
var songInfo = []; //存储所有歌曲信息
var count = []; //歌曲长度
var nowIndex = 0; //当前播放歌曲
var userInput = [];//用户选择的关键词 存放 用来校验
// console.log(jsonData);

var l = [];
//保存所有歌曲的歌名长度
for (let i = 0; i < jsonData.data.length; i++) {
    l.push(jsonData.data[i].songname.length)
}
songInfo = jsonData.data;
count = l;
//动态设置每题播放器src
let songName = () => {
    // console.log(document.getElementById('audio'));
    document.getElementById('audio').src = songInfo[nowIndex].src
}


let now = () => {
    userInput = [];
    //切题删除
    for (let i = document.getElementsByClassName('keyInputDiv')[0].childNodes.length - 1; i >= 0; i--) {
        document.getElementsByClassName('keyInputDiv')[0].removeChild(document.getElementsByClassName('keyInputDiv')[0].childNodes[i]);
    }
    for (let i = document.getElementsByClassName('keyDiv')[0].childNodes.length - 1; i >= 0; i--) {
        document.getElementsByClassName('keyDiv')[0].removeChild(document.getElementsByClassName('keyDiv')[0].childNodes[i]);
    }
    //设置用户输入关键词最大长度
    for (let i = 0; i < count[nowIndex]; i++) {
        userInput.push("");
    }
    //动态添加答题区节点
    for (let i = 0; i < count[nowIndex]; i++) {
        // console.log(i);
        let cdiv = document.createElement('div');
        let pdiv = document.getElementsByClassName('keyInputDiv');
        // console.log(pdiv);
        cdiv.classList.add("keyInput");
        pdiv[0].appendChild(cdiv);
    }
    //动态添加选择区节点
    for (let i = 0; i < songInfo[nowIndex].keyword.length; i++) {
        let cdiv = document.createElement('div');
        let pdiv = document.getElementsByClassName('keyDiv');
        cdiv.classList.add("key");
        cdiv.innerText = songInfo[nowIndex].keyword[i]
        pdiv[0].appendChild(cdiv);
    }
    document.getElementById('current').innerText = "当前第"+(nowIndex+1)+"首，共有"+jsonData.data.length+"首"
    let hh = up();
}
let up = () => {
    //用户输入关键词绑定点击事件
    let keyDown = document.getElementsByClassName('key');
    // console.log(keyDown);
    for (let index = 0; index < keyDown.length; index++) {
        keyDown[index].addEventListener('click', () => {
            // console.log(keyDown[index].innerText);
            //userinput保留用户选择
            for (let i = 0; i < userInput.length; i++) {
                if (userInput[i] == "") {
                    userInput[i] = keyDown[index].innerText;
                    break;
                }
            }
            //动态添加答题区内容 实现双向绑定
            for (let k = 0; k < document.getElementsByClassName('keyInputDiv')[0].childNodes.length; k++) {
                if (document.getElementsByClassName('keyInputDiv')[0].childNodes[k].innerText == "") {
                    document.getElementsByClassName('keyInputDiv')[0].childNodes[k].innerText = keyDown[index].innerText;
                    break;
                }
            }
            //判断用户是否输入完整 进行匹配
            if (userInput[userInput.length - 1] != "") {
                //匹配成功进入
                if (songInfo[nowIndex].songname == userInput.join('')) {
                    alert("恭喜你答对了！"+songInfo[nowIndex].songname)
                    nowIndex += 1;
                    let jj = now();
                    let go = songName();
                } else {
                    alert("再接再厉哟~");
                    let jj = now();
                    // userInput = [];
                    // for (let i = 0; i < count[nowIndex]; i++) {
                    //     userInput.push("");
                    // }
                }
            }
        })
    }
}
let test = now();

let go = songName();



// let rush = up();